# Install-SRSv2-OS-Updates.ps1
$strPath = split-path -parent $MyInvocation.MyCommand.Definition
$total = gci $strPath *.msu | measure | Select-Object -expand Count
$i = 0
gci $strPath *.msu | ForEach-Object {
    $i++
    WUSA ""$_.FullName /quiet /norestart""
    Write-Progress -activity "Applying Updates" -status "Installing $_ .. $i of $total" -percentComplete (($i / $total) * 100)
    Wait-Process -name wusa
}