[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [string]$TenantName,
    [Parameter(Mandatory)]
    [string]$SiteOwner,
    [Parameter(Mandatory)]
    [string]$SPPageName
)

# Define Parameters
$AdminCenterURL = "https://$TenantName-admin.sharepoint.com/"
$PageName = "$SPPageName"
$SiteURL = "https://$TenantName.sharepoint.com/sites/$PageName"
$SiteTitle = "Crisis Management"
$SiteOwner = "$SiteOwner"

Write-Output "Creating SharePoint site"

# Connect to SharePoint Online
function Connect {
    Write-Output "Connecting to SPOService"
    Connect-SPOService -Url $AdminCenterURL -Credential (Get-Credential)
}

# Create new communication site
function CreateSite {
    Write-Output "Creating SharePoint site"
    New-SPOSite -Url $SiteURL -Owner $SiteOwner -Template "SITEPAGEPUBLISHING#0" -StorageQuota 2048 -Title $SiteTitle
}

try
{
    Connect
    CreateSite
    Write-Output "SharePoint site $SPPageName created!"
}
catch
{
    Write-Output "Error creating SharePoint site: $_"
}


