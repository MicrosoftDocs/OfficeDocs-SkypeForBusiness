[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [string]$TenantName,
    [Parameter(Mandatory)]
    [string]$SPPageName
)

try
{
    Write-Output "Building Teams app manifest"

    # generate a new GUID for the Teams App
    $newGuid = [guid]::NewGuid()

    # read in the manifest config
    $manifest = Get-Content "./config/sfpx-manifest.json" -raw | ConvertFrom-Json

    # update values in the manifest using the parameters passed into the script
    $manifest.id = $newGuid
    $manifest.packageName = "com.$TenantName.covid19.app"
    $manifest.developer.websiteUrl = "https://$TenantName.sharepoint.com/sites/$SPPageName"
    $manifest.developer.privacyUrl = "https://$TenantName.sharepoint.com/sites/$SPPageName"
    $manifest.developer.termsOfUseUrl = "https://$TenantName.sharepoint.com/sites/$SPPageName"

    $manifest.staticTabs[0].websiteUrl = "https://$TenantName.sharepoint.com/sites/$SPPageName"
    $manifest.staticTabs[0].contentUrl = "https://$TenantName.sharepoint.com/sites/$SPPageName/_layouts/15/teamslogon.aspx?SPFX=true&dest=/sites/$SPPageName"

    $manifest.validDomains = "$TenantName.sharepoint.com", "*.microsoft.com"

    $manifest.webApplicationInfo.resource = "https://$TenantName.sharepoint.com"

    # convert back to JSON and output the results as manifest.json into the app folder
    ConvertTo-Json -InputObject $manifest -Depth 12 | % {
        [Regex]::Replace($_, 
            "\\u(?<Value>[a-zA-Z0-9]{4})", {
                param($m) ([char]([int]::Parse($m.Groups['Value'].Value,
                    [System.Globalization.NumberStyles]::HexNumber))).ToString() } )} | Set-Content -Path "./app/manifest.json"
}
catch
{
    Write-Output "Error creating building Teams app manifest: $_"
}


