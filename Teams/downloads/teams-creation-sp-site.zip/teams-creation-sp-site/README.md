# teamscovid
These scripts pins an existing sharepoint site as an app within Microsoft Teams. If no sharepoint site exists, the scripts can provision a basic (blank) site if needed.

Required information:
1. Tenant name
2. Site owner credentials (email and password)
3. URL path name for the sharepoint site (this will be part of the final URL)

Required PowerShell Modules (can be installed and imported using the -runSetup option)
1. Microsoft.Online.SharePoint.PowerShell
```
Install-Module -Name Microsoft.Online.SharePoint.PowerShell
```
2. MicrosoftTeams
```
Install-Module -Name MicrosoftTeams
```

start.ps1 - end to end script that installs a Teams app that points to your sharepoint site. Can also provision a basic sharepoint site using the -includeSPO flag (see below).

Usage
```
start.ps1 -TenantName [string] -SiteOwner [string - email] -PageName [string - name used in sharepoint url - one word, no spaces]
```

Example
```
./start.ps1 -TenantName contoso -SiteOwner john@contoso.com -PageName covidresponse -runSetup 1
```

Additional Options

1. Install and import required PowerShell modules
```
-runSetup 1
```

2. Creat basic SharePoint site (if doesn't already exist)
```
-includeSPO 1
```
