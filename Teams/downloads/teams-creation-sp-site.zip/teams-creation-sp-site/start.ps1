[CmdletBinding()]
param (
    [Parameter(Mandatory)]
    [string]$TenantName,
    [Parameter(Mandatory)]
    [string]$SiteOwner,
    [Parameter(Mandatory)]
    [string]$PageName,
    [Parameter()]
    [boolean]$runSetup,
    [Parameter()]
    [boolean]$includeSPO
)

if ($runSetup) {
    Install-Module -Name Microsoft.Online.SharePoint.PowerShell
    Install-Module -Name MicrosoftTeams

    Import-Module Microsoft.Online.SharePoint.PowerShell
    Import-Module MicrosoftTeams
}

if ($includeSPO) {
    # create the basic sharepoint site
    invoke-expression -Command "$PSScriptRoot\createSPSite.ps1 -SiteOwner $SiteOwner -TenantName $TenantName -SPPageName $PageName"
}
# create the teams app
invoke-expression -Command "$PSScriptRoot\buildManifest.ps1 -TenantName $TenantName -SPPageName $PageName"
# install and pin the teams app
invoke-expression -Command "$PSScriptRoot\pinApp.ps1"
