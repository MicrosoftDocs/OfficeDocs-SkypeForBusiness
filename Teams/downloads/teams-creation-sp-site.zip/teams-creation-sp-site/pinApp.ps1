$appArchivePath = "./app/newApp.zip"
$colorLogoPath = "./app/color.png"
$outlineLogoPath = "./app/outline.png"
$manifestJSONPath = "./app/manifest.json"

function Archive {
    # create the application zip with all the required files
    $compress = @{
        Path = $colorLogoPath, $outlineLogoPath, $manifestJSONPath
        DestinationPath = $appArchivePath
    }
    Compress-Archive @compress -Force
}

function Connect {
    Write-Output "Connecting to Microsoft Teams"
    Connect-MicrosoftTeams -Credential (Get-Credential)
}

function CreateTeamsApp {
    Write-Output "Creating Teams App"

    # resolve the relative app path to get the full absolute path
    $manifestPath = Resolve-Path -Path $appArchivePath
    # create the new Teams app
    New-TeamsApp -DistributionMethod organization -Path $manifestPath
}

try
{
    Archive
    Connect
    CreateTeamsApp
    Write-Output "Teams app created!"
}
catch
{
    Write-Output "Error creating Teams app: $_"
}

